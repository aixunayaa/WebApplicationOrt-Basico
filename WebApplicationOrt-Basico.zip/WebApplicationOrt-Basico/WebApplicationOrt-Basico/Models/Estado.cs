﻿namespace WebApplicationOrt_Basico.Models
{
    public enum Estado
    {
        PENDIENTE,
        EN_PROCESO,
        FINALIZADO
    }
}
