﻿namespace WebApplicationOrt_Basico.Models
{
    public enum Genero
    {
        MASCULINO = 1,
        FEMENINO = 2
    }
}
